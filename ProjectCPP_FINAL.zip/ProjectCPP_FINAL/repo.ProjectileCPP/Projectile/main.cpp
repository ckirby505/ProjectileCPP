//
//  main.cpp
//  Projectile -  a program to plot displacement of a projectile with initial velocity at a specified angle
//               accounts for drag as a function of drag coefficient, reference area, air density, velocity
/*
//              Equation used was Impulse of Drag Force = Impulse from momentum
//              
                Force_drag x time_applied = Mass x (v2 - v1)
 
                Force_drag = 0.5 x air_mass_density x Velocity^2 x Drag_coefficient x Reference_Area
//
 */
//  Created by Chris Kirby on 1/12/19.
//  Copyright © 2019 Kirby. All rights reserved.
//


// NOTE: This is a great tool for plotting the data: https://plot.ly/create/#/

//include needed libraries
#include <iostream>
#include "Projectile.hpp"
#include <math.h>
#include <string>


int main(int argc, const char * argv[]) {
    
    
    //class models the behavior of a projectile
    Projectile projectile;
    
    //set initial values needed for calculations
    projectile.setAngleDegrees(65);
    projectile.setDragCoefficient(0.47);
    
    projectile.setInitialVelocityMPS(100);
    projectile.setProjectileDiameterM(.1143);
    projectile.setMassKG(.145);
    projectile.setTimeDeltaS(.1);
    projectile.setFilePath("/Users/chris/Documents/FINALEPROJECTILE");
    
    std::vector<Projectile::point> trajectory_vector = projectile.getTrajectory();
    
    printf("writing displacement data to csv.\n");
    projectile.writeDisplacementDataToCSV();
    
    for (int i=0; i<trajectory_vector.size(); i++){
        printf("(x,y) = (%f, %f)\n", trajectory_vector[i].x, trajectory_vector[i].y);
    }
    
    
    
    
    return 0;
}
