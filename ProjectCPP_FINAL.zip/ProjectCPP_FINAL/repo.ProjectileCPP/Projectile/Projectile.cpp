//
//  Projectile.cpp
//  Projectile - class models the behavior of a projectile
//
//  Created by Chris Kirby on 1/12/19.
//  Copyright © 2019 Kirby. All rights reserved.
//

#include "Projectile.hpp"




/*
 constructor method
 */
Projectile::Projectile(){
    
    
    
}

/*
 convert degrees to radians
 */
double Projectile::degreesToRadians(double degrees){
    double radians = degrees * (M_PI / 180);
    
    return radians;
}

/*
 calculate the initial velocity components for x and y for the initial instant
*/
void Projectile::getInitialXAndYVelocities(){
    
    //x velocity compenent
    this->current_x_mps = this->initial_velocity_mps * cos(this->degreesToRadians(this->angle_deg));
    
    //y velocity component
    this->current_y_mps = this->initial_velocity_mps * sin(this->degreesToRadians(this->angle_deg));
    
    //used to prevent this method from running more than once in another method
    this->initial_velocities_set = true;
}


/*
 calculate cross sectional area of projectile (assumed sphere)
 */
void Projectile::setReferenceAreaM2(double sphere_diameter){
    double radius = sphere_diameter/2;
    this->reference_area_m2 = M_PI * pow(radius, 2);
    
}


/*
    method will return a one dimensional array, each element containing a point object with an x and y property, which is the position with respect to the origin (0,0)
 */
std::vector<Projectile::point> Projectile::getTrajectory(){
    
    //set the reference area of the projectile
    this->setReferenceAreaM2(this->projectile_diameter_m);
    
    //we have to know the initial x and y velocities from the angle of fire and initial velocity
    if (!this->initial_velocities_set){
        this->getInitialXAndYVelocities();
    }
    
    //calculate velocities for both x and y velocity vector components
    
    double displacement_x    = 0;
    double displacement_y    = 0;
    
    
    while (this->total_y_displacement >= 0){
        
        //these are displacements from the previous position we sampled, not necessarily the origin
        
        /*
            change in velocity due to drag:
                Need to know the change in velocity due to drag as a result of impulse applied by drag and momentum
                F(t2-t1) = M(v2 - v1);
         
         */
        
        //instantaneous x velocity
        this->current_x_mps = this->finalVelocityDueToDragImpulse(this->mass_kg, this->unit_of_time_s, this->drag_coefficient, this->reference_area_m2, this->current_x_mps, this->fluid_density_kgmm3);
        
        
        //instantaneous y velocity
        this->current_y_mps = this->current_y_mps - this->gravity_acceleration*this->unit_of_time_s;
        
        
        //instantaneous x displacement
        displacement_x = this->current_x_mps * this->unit_of_time_s;
        
        //instantaneous y displacement
        displacement_y = this->current_y_mps * this->unit_of_time_s;
        
        //track total displacement in x and y directions
        this->total_x_displacement = this->total_x_displacement + displacement_x;
        this->total_y_displacement = this->total_y_displacement + displacement_y;
        
        
        //store x and y position (displacement) coordinates as a point
        point point{this->total_x_displacement, this->total_y_displacement};
        
        //add point to array
        this->trajectory_vector.push_back(point);
        
        
        
        
    }
    
    
    
    return this->trajectory_vector;
}


/*
 export the x and y displacement coordinates to csv file
 */
void Projectile::writeDisplacementDataToCSV(){
    
    std::ofstream outfile(this->file_path + "/displacement-data.csv");
    
    for (int i=0; i<this->trajectory_vector.size(); i++){
        
        outfile << this->trajectory_vector[i].x << "," << this->trajectory_vector[i].y << std::endl;
        
    }
    
}

/*
 this actually calculates instantaneous displacement
 */
double Projectile::finalVelocityDueToDragImpulse(double mass, double time_applied, double drag_coefficient, double reference_area, double initial_velocity, double fluid_density_kgmm3){
    /*
     From Fd * T = m(V2-V1);  (Drag force x time) = mass ( V2 -v1);
     Assuming average velocity of Vi=initial velocity;
     */
    
    
    double final_velocity = -1*(this->fluid_density_kgmm3*pow(initial_velocity,2)*drag_coefficient*reference_area*time_applied);
    
    final_velocity = final_velocity/2;
    
    final_velocity = final_velocity + initial_velocity;
    
    return final_velocity;
}

/*
    calculated drag force on projectile
 */
double Projectile::dragForce(double p, double u, double Cd, double A){
    
    /*
     some variables for drag equations
     
     p: fluid mass density
     u: flow speed of object relative to fluid
     A: Reference area of object
     Fd: drag force
     */

    
    double drag_force = .5 * p * pow(u, 2) * Cd * A;
    
    return drag_force;
}




//setter methods

void Projectile::setAngleDegrees(double angle_deg){
    this->angle_deg = angle_deg;
}
void Projectile::setInitialVelocityMPS(double initial_velocity_mps){
    this->initial_velocity_mps = initial_velocity_mps;
}
void Projectile::setProjectileDiameterM(double projectile_diameter_m){
    this->projectile_diameter_m = projectile_diameter_m;
}
void Projectile::setDragCoefficient(double drag_coefficient){
    this->drag_coefficient = drag_coefficient;
}
void Projectile::setMassKG(double mass_kg){
    this->mass_kg = mass_kg;
}
void Projectile::setTimeDeltaS(double unit_of_time){
    this->unit_of_time_s = unit_of_time;
}
void Projectile::setFilePath(std::string file_path){
    this->file_path = file_path;
}

