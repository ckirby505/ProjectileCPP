//
//  Projectile.cpp
//  Projectile
//
//  Created by Chris Kirby on 1/12/19.
//  Copyright © 2019 Kirby. All rights reserved.
//

#include "Projectile.hpp"



/*
 p: fluid mass density
 u: flow speed of object relative to fluid
 A: Reference area of object
 Fd: drag force
 */

Projectile::Projectile(){
    
    
    
}

double Projectile::degreesToRadians(double degrees){
    double radians = degrees * (M_PI / 180);
    
    return radians;
}

void Projectile::getInitialXAndYVelocities(){
    
    this->current_x_mps = this->initial_velocity_mps * cos(this->degreesToRadians(this->angle_deg));
    
    this->current_y_mps = this->initial_velocity_mps * sin(this->degreesToRadians(this->angle_deg));
    
    this->initial_velocities_set = true;
}

void Projectile::setReferenceAreaM2(double sphere_diameter){
    double radius = sphere_diameter/2;
    this->reference_area_m2 = M_PI * pow(radius, 2);
    
}


/*
    method will return a one dimensional array, each element containing a point object with an x and y property, which is the position with respect to the origin (0,0)
 */
std::vector<Projectile::point> Projectile::getTrajectory(){
    
    //some configurations
    this->setReferenceAreaM2(this->projectile_diameter_m);
    
    //we have to know the initial x and y velocities
    if (!this->initial_velocities_set){
        this->getInitialXAndYVelocities();
    }
    
    //calculate velocities for both x and y velocity vector components
    double displacement_x    = 0;
    double displacement_y    = 0;
    
    
    while (this->total_y_displacement >= 0){
        
        //displacement for x vector
        
        //these are displacements from the previous position we sampled, not necessarily the origin
        
        
        
        /*
            change in velocity due to drag:
                Need to know the change in velocity due to drag
                F(t2-t1) = M(v2 - v1);
         
         */
        
        this->current_x_mps = this->finalVelocityDueToDragImpulse(this->mass_kg, this->unit_of_time_s, this->drag_coefficient, this->reference_area_m2, this->current_x_mps, this->fluid_density_kgmm3);
        
        
        this->current_y_mps = this->current_y_mps - this->gravity_acceleration*this->unit_of_time_s;
        
        
        
        displacement_x = this->current_x_mps * this->unit_of_time_s;
        
        displacement_y = this->current_y_mps * this->unit_of_time_s;
        
        
        this->total_x_displacement = this->total_x_displacement + displacement_x;
        this->total_y_displacement = this->total_y_displacement + displacement_y;
        
        
        point point{this->total_x_displacement, this->total_y_displacement};
        
        
        this->trajectory_vector.push_back(point);
        
        
        
        
    }
    
    
    
    return this->trajectory_vector;
}

void Projectile::writeDisplacementDataToCSV(){
    
    std::ofstream outfile(this->file_path + "/displacement-data.csv");
    
    for (int i=0; i<this->trajectory_vector.size(); i++){
        
        outfile << this->trajectory_vector[i].x << "," << this->trajectory_vector[i].y << std::endl;
        
    }
    
}

double Projectile::finalVelocityDueToDragImpulse(double mass, double time_applied, double drag_coefficient, double reference_area, double initial_velocity, double fluid_density_kgmm3){
    /*
     From Fd * T = m(V2-V1);  (Drag force x time) = mass ( V2 -v1);
     Assuming average velocity of Vi=initial velocity;
     */
    
    
    double final_velocity = -1*(this->fluid_density_kgmm3*pow(initial_velocity,2)*drag_coefficient*reference_area*time_applied);
    
    final_velocity = final_velocity/2;
    
    final_velocity = final_velocity + initial_velocity;
    
    return final_velocity;
}


double Projectile::dragForce(double p, double u, double Cd, double A){
    
    double drag_force = .5 * p * pow(u, 2) * Cd * A;
    
    return drag_force;
}




//setter methods

void Projectile::setAngleDegrees(double angle_deg){
    this->angle_deg = angle_deg;
}
void Projectile::setInitialVelocityMPS(double initial_velocity_mps){
    this->initial_velocity_mps = initial_velocity_mps;
}
void Projectile::setProjectileDiameterM(double projectile_diameter_m){
    this->projectile_diameter_m = projectile_diameter_m;
}
void Projectile::setDragCoefficient(double drag_coefficient){
    this->drag_coefficient = drag_coefficient;
}
void Projectile::setMassKG(double mass_kg){
    this->mass_kg = mass_kg;
}
void Projectile::setTimeDeltaS(double unit_of_time){
    this->unit_of_time_s = unit_of_time;
}
void Projectile::setFilePath(std::string file_path){
    this->file_path = file_path;
}

