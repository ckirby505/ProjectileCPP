//
//  main.cpp
//  Projectile
//
//  Created by Chris Kirby on 1/12/19.
//  Copyright © 2019 Kirby. All rights reserved.
//


// NOTE: This is a great tool for plotting the data.

#include <iostream>
#include "Projectile.hpp"
#include <math.h>
#include <string>

int main(int argc, const char * argv[]) {
    // insert code here...
    
    
    
    
    
    Projectile projectile;
    
    projectile.setAngleDegrees(85);
    projectile.setDragCoefficient(0.47);
    
    projectile.setInitialVelocityMPS(100);
    projectile.setProjectileDiameterM(.1143);
    projectile.setMassKG(.145);
    projectile.setTimeDeltaS(.1);
    projectile.setFilePath("/Users/chris/Documents/ProjectileCPP");
    std::vector<Projectile::point> trajectory_vector = projectile.getTrajectory();
    
    printf("writing displacement data to csv.\n");
    projectile.writeDisplacementDataToCSV();
    
    for (int i=0; i<trajectory_vector.size(); i++){
        printf("(x,y) = (%f, %f)\n", trajectory_vector[i].x, trajectory_vector[i].y);
    }
    
    
    
    
    return 0;
}
