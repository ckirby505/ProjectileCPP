//
//  Projectile.hpp
//  Projectile
//
//  Created by Chris Kirby on 1/12/19.
//  Copyright © 2019 Kirby. All rights reserved.
//

#ifndef Projectile_hpp
#define Projectile_hpp

#include <stdio.h>
#include <math.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <string.h>



class Projectile {
    
    /*
        angle:      initial firing angle
        mps:        meters per second exiting barrel
        diameter:   diameter of projectile in meters
        iterations: the number of time to iterate
     */
    
    
public:
    
    struct point {
        double x;
        double y;
    };
    
    double unit_of_time_s = 1;
    
    double angle_deg;
    double initial_velocity_mps;
    double projectile_diameter_m;
    double reference_area_m2;
    double drag_coefficient;
    
    
    double gravity_acceleration = 9.81; //m/s^2
    
    double fluid_density_kgmm3 = 1.1455; //kg/mmm^3
    
    std::string file_path;
    
    
    bool initial_velocities_set = false;
    double current_x_mps;
    double current_y_mps;
    double current_x;
    double current_y;
    double mass_kg;
    
    double total_y_displacement = 0;
    double total_x_displacement = 0;
    
    std::vector<point> trajectory_vector;
    
    Projectile();
    double dragForce(double fluid_mass_density, double initial_velocity, double drag_coefficient, double reference_area);
   
    void getInitialXAndYVelocities();
    
    std::vector<Projectile::point> getTrajectory();
    
    void setAngleDegrees(double angle_deg);
    void setInitialVelocityMPS(double initial_velocity_mps);
    void setProjectileDiameterM(double projectile_diameter_m);
    void setDragCoefficient(double drag_coefficient);
    void setMassKG(double mass_kg);
    void setTimeDeltaS(double unit_of_time);
    void setFilePath(std::string file_path);
    
    void writeDisplacementDataToCSV();
    double degreesToRadians(double degrees);
    double finalVelocityDueToDragImpulse(double mass, double time_applied, double drag_coefficient, double reference_area, double initial_velocity, double fluid_density_kgmm3);
    
private:
    void setReferenceAreaM2(double sphere_diameter);
    
};

#endif /* Projectile_hpp */
